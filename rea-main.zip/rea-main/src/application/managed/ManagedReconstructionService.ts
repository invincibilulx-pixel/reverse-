import { z } from "zod";

import { AnalysisProtocolError } from "../../domain/analysisErrorCore.js";
import { type AnalysisError } from "../../domain/analysisErrorBase.js";
import { createEvidence, type Evidence } from "../../domain/evidence.js";
import { jsonValueSchema } from "../../domain/jsonValue.js";
import {
  importManagedReconstruction,
  managedReconstructionImportInputSchema,
  type ManagedReconstructionImportInput,
  type ManagedReconstructionImportResult,
} from "../../domain/managed/managedReconstruction.js";
import { err, ok, type Result } from "../../domain/result.js";
import { MANAGED_WORKFLOW_PROVIDER } from "../InvestigationProviders.js";
import {
  requestInputError,
  workflowInputError,
} from "../workflowInputError.js";

const OPERATION = "import_managed_reconstruction" as const;

/** Authenticate and import managed decompiler reconstruction as Evidence. */
export const importManagedReconstructionEvidence = (
  rawInput: unknown,
): Result<Evidence, AnalysisError> => {
  const parsed = managedReconstructionImportInputSchema.safeParse(rawInput);
  if (!parsed.success)
    return err(requestInputError(OPERATION, parsed.error, rawInput));
  return importManagedReconstructionEvidenceValidated(parsed.data);
};

/** Import reconstruction from input parsed by a trusted adapter. */
export const importManagedReconstructionEvidenceValidated = (
  input: ManagedReconstructionImportInput,
): Result<Evidence, AnalysisError> => {
  try {
    const result = importManagedReconstruction(input);
    return ok(createManagedReconstructionEvidence(input, result));
  } catch (cause: unknown) {
    return err(
      cause instanceof TypeError || cause instanceof z.ZodError
        ? workflowInputError(OPERATION, cause)
        : new AnalysisProtocolError(
            "Managed reconstruction import produced an invalid result",
            { cause },
          ),
    );
  }
};

const createManagedReconstructionEvidence = (
  input: ManagedReconstructionImportInput,
  result: ManagedReconstructionImportResult,
): Evidence =>
  createEvidence(
    {
      path: result.static_observation.artifact_path,
      sha256: result.static_observation.artifact_sha256,
      format: "pe",
    },
    MANAGED_WORKFLOW_PROVIDER,
    {
      predicateType: "rea.managed-reconstruction-import",
      operation: OPERATION,
      parameters: {
        static_members_evidence_id: input.static_members.evidence_id,
        decompiler: jsonValueSchema.parse(result.decompiler),
        method_locks: jsonValueSchema.parse(
          input.methods.map(
            ({ token, signature_sha256, normalized_il_sha256 }) => ({
              token,
              signature_sha256,
              normalized_il_sha256,
            }),
          ),
        ),
        notes: jsonValueSchema.parse(input.notes),
      },
      result: jsonValueSchema.parse(result),
      rawResult: null,
      confidence: "inferred",
      authority: "analyst-inference",
      environment: null,
      limitations: result.limitations,
      locations: [
        {
          kind: "artifact-path",
          path: result.static_observation.artifact_path,
        },
      ],
      evidenceLinks: result.evidence_links,
    },
  );
